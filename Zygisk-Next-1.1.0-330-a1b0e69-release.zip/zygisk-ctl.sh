MODDIR=${0%/*}/..


exec $MODDIR/bin/zygiskd64 ctl $*
